import React from 'react'
const Neighborhood = () => {
  return(<h2>Neighborhood</h2>);
};

export default Neighborhood;
