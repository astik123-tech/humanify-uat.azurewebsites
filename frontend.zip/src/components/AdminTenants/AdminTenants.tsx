export const AdminTenants =()=>{
    return ( <div>Tenants</div>)
}