import React from 'react'
const MyDesk = () => {
  return (<h2>My Desk</h2>);
};

export default MyDesk;
