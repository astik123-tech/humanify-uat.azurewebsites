export const AdminZoom =()=>{
    return (
        <div>Zoom Channels</div>
    )
}