export const AdminGroups =()=>{
    return (
        <div>
            Groups
        </div>
    )
}