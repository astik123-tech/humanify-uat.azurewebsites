export const AdminConfigurations = ()=>{
    return (<div>Configurations</div>)
}