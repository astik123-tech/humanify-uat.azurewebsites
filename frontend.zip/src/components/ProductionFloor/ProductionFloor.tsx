import React from 'react'
const ProductionFloor = () => {
  return (<h2>Production FLoor</h2>);
};

export default ProductionFloor;
